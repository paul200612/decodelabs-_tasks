"""
Phase 0 - photorealistic synthetic validation dataset for the
Automated Quality Inspection project (v2).

v1 drew flat filled polygons: correct silhouettes, but obviously fake and far
too easy to threshold. v2 renders the scene physically:

  * height field -> surface normals -> Lambertian + Blinn-Phong shading
  * chamfered rim, lathe/turning marks, brushed anisotropic streaks
  * modular conveyor belt with seams, rubber texture, dust and scuffs
  * directional soft shadow, ambient occlusion contact darkening
  * specular hotspot + bloom (the classic metal-part glare problem)
  * lens vignette, defocus, photon shot noise, 2x supersampling

Part: machined disc, two flats, plus a keyway notch ~10 px deep present on
EVERY part (good and bad) so THRESHOLD_MAX must be calibrated, not set to ~0.
Defects: rim chips (wedge) and cracks (thin radial slot).

Output: dataset/images/part_NN.png, dataset/masks/part_NN.png, dataset/labels.csv

    python generate_dataset.py            # the validation set
    python generate_dataset.py --stress   # + dataset/stress/, the lighting torture test
    python generate_dataset.py --video    # + dataset/conveyor.mp4, a moving-belt clip

The stress set re-lights the SAME 20 parts under conditions a real line throws at
you: a steep illumination gradient across the belt, blown-out specular glare, and
under- or over-exposure. Geometry is untouched, so labels.csv still applies - only
the photometry changes, which is exactly what Phase 5 dynamic thresholding has to
survive.
"""

import csv
import os
import numpy as np
import cv2

SEED = 20260908
W, H = 640, 480
SS = 2                     # supersampling factor
RW, RH = W * SS, H * SS

R = 110.0 * SS             # nominal part radius
FLAT_D = 96.0 * SS         # centre -> machined flat
KEYWAY_DEPTH = 10.0 * SS
THICK = 13.0 * SS          # part thickness (height field units = px)
CHAMFER = 6.0 * SS         # rim chamfer width

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dataset")
rng = np.random.default_rng(SEED)


# ------------------------------------------------------------------ geometry
def profile_radius(theta, phi0):
    r = np.full_like(theta, R)
    for flat in (phi0, phi0 + np.pi):
        c = np.cos(theta - flat)
        lim = np.where(c > 1e-6, FLAT_D / np.maximum(c, 1e-6), np.inf)
        r = np.minimum(r, lim)
    return r


def outline(cx, cy, phi0, wobble=0.6 * SS):
    th = np.linspace(0, 2 * np.pi, 1440, endpoint=False)
    r = profile_radius(th, phi0) + rng.normal(0, wobble, 1440)
    return np.stack([cx + r * np.cos(th), cy + r * np.sin(th)], 1).astype(np.int32)


def wedge_cut(cx, cy, phi0, theta_c, half_width, depth):
    th = np.linspace(theta_c - half_width, theta_c + half_width, 80)
    r_out = profile_radius(th, phi0) + 25 * SS
    r_in = profile_radius(th, phi0) - depth
    outer = np.stack([cx + r_out * np.cos(th), cy + r_out * np.sin(th)], 1)
    inner = np.stack([cx + r_in * np.cos(th), cy + r_in * np.sin(th)], 1)
    return np.concatenate([outer, inner[::-1]]).astype(np.int32)


def crack_cut(cx, cy, phi0, theta_c, depth, width):
    r_rim = float(profile_radius(np.array([theta_c]), phi0)[0])
    tip = np.array([cx + (r_rim - depth) * np.cos(theta_c),
                    cy + (r_rim - depth) * np.sin(theta_c)])
    mouth = np.array([cx + (r_rim + 25 * SS) * np.cos(theta_c),
                      cy + (r_rim + 25 * SS) * np.sin(theta_c)])
    d = mouth - tip
    d /= np.linalg.norm(d)
    n = np.array([-d[1], d[0]]) * (width / 2.0)
    return np.array([tip + n, mouth + n, mouth - n, tip - n]).astype(np.int32)


# ------------------------------------------------------------------ textures
def fractal_noise(shape, octaves=5, base=4):
    out = np.zeros(shape)
    amp = 1.0
    for o in range(octaves):
        k = base * (2 ** o)
        small = rng.normal(0, 1, (max(2, shape[0] * k // shape[1] or 2), max(2, k)))
        out += amp * cv2.resize(small, (shape[1], shape[0]), interpolation=cv2.INTER_CUBIC)
        amp *= 0.5
    return out / np.abs(out).max()


def belt_albedo():
    """Modular plastic conveyor belt: slats, seams, rubber grain, dust, scuffs."""
    a = np.full((RH, RW), 0.200)
    a += 0.020 * fractal_noise((RH, RW), octaves=5, base=6)

    # transverse slat seams (belt runs top -> bottom)
    pitch = int(96 * SS)
    off = int(rng.integers(0, pitch))
    skew = rng.uniform(-0.02, 0.02)
    yy, xx = np.mgrid[0:RH, 0:RW]
    phase = (yy + skew * xx + off) % pitch
    seam = np.exp(-((phase - 0) ** 2) / (2 * (2.2 * SS) ** 2)) + \
           np.exp(-((phase - pitch) ** 2) / (2 * (2.2 * SS) ** 2))
    a -= 0.055 * seam
    a += 0.012 * np.exp(-((phase - 3.5 * SS) ** 2) / (2 * (2.0 * SS) ** 2))  # seam lip catches light

    # fine moulded grain running along the belt
    a += 0.010 * np.sin(xx / (2.4 * SS) + 2.0 * fractal_noise((RH, RW), 3, 8))

    # scuffs and dust
    for _ in range(rng.integers(8, 16)):
        p1 = (int(rng.integers(0, RW)), int(rng.integers(0, RH)))
        p2 = (p1[0] + int(rng.integers(-90, 90) * SS), p1[1] + int(rng.integers(-25, 25) * SS))
        cv2.line(a, p1, p2, float(rng.uniform(0.19, 0.26)),
                 thickness=int(rng.integers(1, 3) * SS))
    for _ in range(rng.integers(25, 60)):
        c = (int(rng.integers(0, RW)), int(rng.integers(0, RH)))
        cv2.circle(a, c, int(rng.integers(1, 4) * SS),
                   float(rng.uniform(0.08, 0.30)), -1)

    return np.clip(a, 0.03, 0.6)


def metal_albedo(cx, cy):
    """Turning marks (concentric) + brushed streaks + slight mottling."""
    yy, xx = np.mgrid[0:RH, 0:RW]
    rad = np.sqrt((xx - cx) ** 2 + (yy - cy) ** 2)
    a = np.full((RH, RW), 0.560)
    a += 0.011 * np.sin(rad / (5.5 * SS))                     # lathe turning marks
    a += 0.009 * np.sin(rad / (17.0 * SS) + 1.3)
    a += 0.020 * fractal_noise((RH, RW), octaves=4, base=10)   # mottling
    streak = cv2.resize(rng.normal(0, 1, (RH // (6 * SS), 4)), (RW, RH),
                        interpolation=cv2.INTER_CUBIC)
    a += 0.022 * streak / (np.abs(streak).max() + 1e-9)
    return np.clip(a, 0.25, 0.95)


# ------------------------------------------------------------------ rendering
def shade(mask, cx, cy):
    m = (mask > 0).astype(np.float64)

    # --- height field: flat top, smooth chamfer at every edge (rim, chip, crack)
    dist_in = cv2.distanceTransform(mask, cv2.DIST_L2, 5)
    s = np.clip(dist_in / CHAMFER, 0, 1)
    height = THICK * (s * s * (3 - 2 * s))
    height = cv2.GaussianBlur(height, (0, 0), 1.2 * SS)

    # --- normals
    gx = cv2.Sobel(height, cv2.CV_64F, 1, 0, ksize=5) / 8.0
    gy = cv2.Sobel(height, cv2.CV_64F, 0, 1, ksize=5) / 8.0
    nz = np.ones_like(gx)
    nrm = np.sqrt(gx * gx + gy * gy + 1.0)
    nx, ny, nz = -gx / nrm, -gy / nrm, nz / nrm

    # --- light
    az = rng.uniform(0, 2 * np.pi)
    el = rng.uniform(0.75, 1.25)
    L = np.array([np.cos(az), np.sin(az), el])
    L /= np.linalg.norm(L)
    Hv = L + np.array([0, 0, 1.0])
    Hv /= np.linalg.norm(Hv)

    ndl = np.clip(nx * L[0] + ny * L[1] + nz * L[2], 0, 1)
    ndh = np.clip(nx * Hv[0] + ny * Hv[1] + nz * Hv[2], 0, 1)

    # --- albedo / material
    alb = belt_albedo() * (1 - m) + metal_albedo(cx, cy) * m
    ks = 0.30 * m + 0.05 * (1 - m)
    shin = 38.0 * m + 8.0 * (1 - m)

    amb = 0.50
    img = alb * (amb + 0.85 * ndl) + ks * np.power(ndh, shin)

    # --- cast shadow on the belt
    shift = (-L[0] * 11 * SS, -L[1] * 11 * SS)
    M = np.float32([[1, 0, shift[0]], [0, 1, shift[1]]])
    sh = cv2.warpAffine(m, M, (RW, RH))
    sh = cv2.GaussianBlur(sh, (0, 0), 6.0 * SS)
    img *= 1.0 - 0.50 * np.clip(sh - m, 0, 1)

    # --- ambient occlusion: contact darkening on belt, and inside chips/cracks
    dist_out = cv2.distanceTransform((mask == 0).astype(np.uint8), cv2.DIST_L2, 5)
    img *= 1.0 - 0.32 * np.exp(-dist_out / (7.0 * SS)) * (1 - m)
    img *= 1.0 - 0.30 * np.exp(-dist_in / (5.0 * SS)) * m

    # --- specular hotspot on the part face + bloom (the glare problem)
    hx = cx + rng.uniform(-0.45, 0.45) * R
    hy = cy + rng.uniform(-0.45, 0.45) * R
    yy, xx = np.mgrid[0:RH, 0:RW]
    d2 = (xx - hx) ** 2 + (yy - hy) ** 2
    hot = np.exp(-d2 / (2 * (rng.uniform(34, 58) * SS) ** 2))
    img += rng.uniform(0.10, 0.22) * hot * m

    bloom = cv2.GaussianBlur(np.clip(img - 0.92, 0, None), (0, 0), 9.0 * SS)
    img += 0.30 * bloom

    # --- camera: vignette, defocus, exposure
    vy, vx = np.mgrid[0:RH, 0:RW]
    vig = 1.0 - 0.26 * (((vx / RW - 0.5) ** 2 + (vy / RH - 0.5) ** 2) / 0.5)
    img *= vig
    img *= rng.uniform(0.92, 1.10)
    img = cv2.GaussianBlur(img, (0, 0), 0.9 * SS)

    # --- to 8-bit BGR with a slight cool metal / warm belt cast
    base = np.clip(img, 0, 1.25) * 205.0
    b = base * (1.00 + 0.045 * m)
    g = base * (1.00 + 0.010 * m)
    r = base * (1.00 - 0.030 * m + 0.030 * (1 - m))
    col = np.stack([b, g, r], -1)

    # --- photon shot noise + read noise, then downsample (anti-aliasing)
    col = col + rng.normal(0, 1, col.shape) * (np.sqrt(np.clip(col, 0, None)) * 0.55 + 1.6)
    col = np.clip(col, 0, 255).astype(np.uint8)
    return cv2.resize(col, (W, H), interpolation=cv2.INTER_AREA)


# ------------------------------------------------------------------ dataset
def build_part(defective):
    cx = RW / 2 + rng.uniform(-45, 45) * SS
    cy = RH / 2 + rng.uniform(-35, 35) * SS
    phi0 = rng.uniform(0, 2 * np.pi)

    mask = np.zeros((RH, RW), np.uint8)
    cv2.fillPoly(mask, [outline(cx, cy, phi0)], 255)

    key_theta = phi0 + np.pi / 2 + rng.uniform(-0.15, 0.15)
    cv2.fillPoly(mask, [wedge_cut(cx, cy, phi0, key_theta, 0.10, KEYWAY_DEPTH)], 0)

    def tip(theta, depth):
        """Deepest point of a wedge/crack cut, in output-resolution pixels."""
        r = float(profile_radius(np.array([theta]), phi0)[0]) - depth
        return round((cx + r * np.cos(theta)) / SS, 1), round((cy + r * np.sin(theta)) / SS, 1)

    kx, ky = tip(key_theta, KEYWAY_DEPTH)
    meta = {"defect_type": "none", "defect_depth_px": 0.0,
            "keyway_x": kx, "keyway_y": ky, "defect_x": "", "defect_y": ""}
    if defective:
        theta = key_theta + rng.uniform(0.9, 2 * np.pi - 0.9)
        if rng.random() < 0.5:
            depth = float(rng.uniform(22, 42))
            cv2.fillPoly(mask, [wedge_cut(cx, cy, phi0, theta,
                                          float(rng.uniform(0.10, 0.28)), depth * SS)], 0)
            dx, dy = tip(theta, depth * SS)
            meta.update({"defect_type": "chip", "defect_depth_px": round(depth, 1),
                         "defect_x": dx, "defect_y": dy})
        else:
            depth = float(rng.uniform(26, 46))
            width = float(rng.uniform(7, 11))
            cv2.fillPoly(mask, [crack_cut(cx, cy, phi0, theta, depth * SS, width * SS)], 0)
            dx, dy = tip(theta, depth * SS)
            meta.update({"defect_type": "crack", "defect_depth_px": round(depth, 1),
                         "defect_x": dx, "defect_y": dy})

    return mask, meta, cx, cy


def make_stress():
    """Re-light the rendered images under hostile conditions.

    Applied as a camera/lighting effect on top of the finished renders rather
    than re-rendering: the geometry (and therefore every label) must stay
    bit-identical, or the stress test would be measuring two things at once.
    """
    src_dir = os.path.join(OUT, "images")
    dst_dir = os.path.join(OUT, "stress")
    os.makedirs(dst_dir, exist_ok=True)

    srng = np.random.default_rng(SEED + 1)      # own stream; main set unaffected
    names = sorted(os.listdir(src_dir))
    yy, xx = np.mgrid[0:H, 0:W]

    for i, name in enumerate(names):
        img = cv2.imread(os.path.join(src_dir, name)).astype(np.float64)
        mask = cv2.imread(os.path.join(OUT, "masks", name),
                          cv2.IMREAD_GRAYSCALE).astype(np.float64) / 255.0

        # 1. severe illumination gradient - lamp well off to one side, so the
        #    shaded edge of the part ends up DARKER than the lit belt opposite.
        #    That is the condition a single global threshold cannot satisfy.
        ang = srng.uniform(0, 2 * np.pi)
        u = np.cos(ang) * (xx / W - 0.5) + np.sin(ang) * (yy / H - 0.5) + 0.5
        img *= (0.15 + 1.15 * np.clip(u, 0, 1))[..., None]

        # 2. specular glare ON THE PART - metal is shiny, the matte belt is not.
        #    Deliberately NOT blown across the belt: saturating the background
        #    merges part and belt into one white blob, and no threshold on earth
        #    separates two regions that are both pure white and touching. That is
        #    an optics problem (polariser, diffuser), not an algorithm problem.
        gx, gy = srng.uniform(0.3, 0.7) * W, srng.uniform(0.3, 0.7) * H
        r = srng.uniform(40, 80)
        glare = np.exp(-(((xx - gx) ** 2 + (yy - gy) ** 2) / (2 * r ** 2))) * mask
        img += (srng.uniform(60, 130) * glare)[..., None]

        # 3. exposure error, alternating under and over
        img *= srng.uniform(0.45, 0.75) if i % 2 else srng.uniform(1.2, 1.5)

        # 4. more sensor noise (short exposure / high gain)
        img += srng.normal(0, 5.0, img.shape)

        cv2.imwrite(os.path.join(dst_dir, name),
                    np.clip(img, 0, 255).astype(np.uint8))

    print(f"wrote {len(names)} stressed images to {dst_dir}")


def make_video(step=16, fps=30):
    """A moving-belt clip: the 20 frames stacked into one long strip, scrolled
    past the camera. Parts drift in and out, so only part of the time is a whole
    part inside the frame - which is the condition the video counter has to
    handle. Nothing is added that is not already in the validation set.
    """
    src_dir = os.path.join(OUT, "images")
    strip = np.vstack([cv2.imread(os.path.join(src_dir, n))
                       for n in sorted(os.listdir(src_dir))])
    out_path = os.path.join(OUT, "conveyor.mp4")

    # codec handling is shared with the inspector - see inspection.open_video_writer
    from inspection import open_video_writer, ensure_playable

    writer, out_path = open_video_writer(out_path, fps, (W, H))
    for y in range(0, strip.shape[0] - H, step):
        writer.write(strip[y:y + H])
    writer.release()
    out_path = ensure_playable(out_path)
    print(f"wrote {out_path} ({(strip.shape[0] - H) // step} frames @ {fps} fps)")


def main():
    img_dir = os.path.join(OUT, "images")
    mask_dir = os.path.join(OUT, "masks")
    os.makedirs(img_dir, exist_ok=True)
    os.makedirs(mask_dir, exist_ok=True)

    plan = ["good"] * 10 + ["defective"] * 10
    rng.shuffle(plan)

    rows = []
    for i, kind in enumerate(plan, start=1):
        mask, meta, cx, cy = build_part(kind == "defective")
        img = shade(mask, cx, cy)
        name = f"part_{i:02d}.png"
        cv2.imwrite(os.path.join(img_dir, name), img)
        # ground-truth silhouette at output resolution (for Phase 1 scoring only)
        gt = cv2.resize(mask, (W, H), interpolation=cv2.INTER_AREA)
        cv2.imwrite(os.path.join(mask_dir, name), (gt > 127).astype(np.uint8) * 255)
        rows.append({"filename": name,
                     "label": "PASS" if kind == "good" else "FAIL", **meta})
        print(f"  {name}  {rows[-1]['label']}  {meta['defect_type']}")

    with open(os.path.join(OUT, "labels.csv"), "w", newline="") as f:
        wtr = csv.DictWriter(f, fieldnames=["filename", "label", "defect_type",
                                            "defect_depth_px", "defect_x", "defect_y",
                                            "keyway_x", "keyway_y"])
        wtr.writeheader()
        wtr.writerows(rows)
    print(f"wrote {len(rows)} images to {img_dir}")


if __name__ == "__main__":
    import sys
    main()
    if "--stress" in sys.argv:
        make_stress()
    if "--video" in sys.argv:
        make_video()
