# Automated Quality Inspection — Computer Vision

An OpenCV pipeline that inspects machined parts on a conveyor belt and returns
PASS / FAIL. It works by measuring where the part's outline dips inside its own
convex hull: a chip or a crack is a gap between the two, and the depth of that
gap in pixels is the whole decision.

**Result: 20/20 on the validation set** — 100% accuracy, precision and recall,
zero false positives, zero false negatives. More usefully, the two populations
sit 10.5 px apart with nothing in between, so *any* tolerance from 12 to 22 px
sorts them correctly. The verdict does not hinge on a tuned number.

![results](figures/results.jpg)

## Quickstart

```bash
pip install -r requirements.txt
python generate_dataset.py --stress --video   # build the dataset (deterministic)
python validate.py                            # score every phase -> results/
python inspection.py dataset/images/          # a verdict per frame
```

```
file            verdict    worst  reason
part_01.png     PASS         9.7  deepest concavity 9.7 px, within the 17 px tolerance
part_02.png     FAIL        24.7  1 defect(s) over tolerance; deepest 24.7 px at (290, 211)
...
20 inspected, 10 rejected, 10 passed  (tolerance 17 px)
```

## How it works

| stage | what it does |
|---|---|
| **1. Pre-process** | grayscale → blur → Otsu threshold → morphological cleanup, leaving a clean silhouette |
| **2. Topology** | outer contour → convex hull → convexity defects: every concavity, with its depth and location |
| **3. Tolerance gate** | deepest concavity vs `THRESHOLD_MAX`; box the offender, emit the verdict |

## Repository

```
inspection.py         the pipeline + CLI (all three stages, plus video mode)
generate_dataset.py   builds the validation set: images, masks, labels, stress set, belt clip
validate.py           scores every phase against ground truth, writes results/
figures.py            regenerates every figure
requirements.txt      opencv, numpy, matplotlib (+ optional ffmpeg, see the file)
dataset/              images/ · masks/ · stress/ · labels.csv · conveyor.mp4   (generated)
figures/              dataset · stages · silhouettes · defects · results · stress
results/              report.md · predictions.csv · margin.png · false-positives.md
                      annotated/ · conveyor_inspected.mp4
```

Four Python files. Each phase extended `inspection.py` and added a section to
`validate.py`; no per-phase scripts were left behind.

`dataset/` is gitignored — it rebuilds bit-for-bit from `SEED = 20260908`, and
10 MB of PNGs does not belong in a repository.

### All commands

```bash
python inspection.py dataset/images/                  # verdicts
python inspection.py dataset/images/ --out runs       # + annotated images
python inspection.py dataset/images/ --dynamic        # illumination-corrected
python inspection.py dataset/conveyor.mp4 --video --out results
python validate.py                                    # all checks -> results/
python validate.py --sweep                            # + blur-kernel sweep
python generate_dataset.py --stress --video           # rebuild all inputs
python figures.py                                     # rebuild figures
```

---

## Phase 0 — Validation dataset ✅

Real internship images are not available yet, so the set is **synthetic but
physically rendered**: height field → surface normals → Lambertian + Blinn-Phong
shading, chamfered rim, lathe turning marks, conveyor slat seams, dust and
scuffs, directional soft shadow, ambient occlusion, specular hotspot and bloom,
lens vignette, defocus, photon shot noise, 2× supersampling.

10 × `PASS`, 10 × `FAIL`, shuffled, 640×480. Filenames carry no label — the
pipeline reads images only; `labels.csv` is for scoring.

**The part:** a machined disc (R ≈ 110 px) with two flats and **a keyway notch
~10 px deep present on every part, good and bad.** That notch is deliberate. It
is a legitimate feature that registers as a real convexity defect, so
`THRESHOLD_MAX` must be *calibrated* rather than set near zero. Set it too low
and all 10 good parts become false positives — the Phase 5 write-up case.

**Defects:** rim chips (wedge, 23–33 px) and cracks (thin radial slot, 33–43 px).

`labels.csv` also records the true deepest point of each cut (`defect_x/y`,
`keyway_x/y`) so Phase 2 can be scored on *location*, not just depth.
`dataset/masks/` holds the true silhouettes for Phase 1 scoring.

---

## Phase 1 — Pre-processing ✅

grayscale → Gaussian blur (9,9) → Otsu threshold → polarity guard →
morphological open+close (5 px ellipse) → keep largest connected component.

### Decisions

- **Otsu, not a fixed threshold.** The selected value ranges 79–108 across these
  20 images. A hard-coded cut-off would drift out of calibration on a real line.
- **Polarity guard.** If the foreground exceeds half the frame the mask is
  inverted, so "part = white" holds even with a dark part, a light belt, or
  backlighting.
- **5 px morphology kernel, deliberately small.** Clears belt dust and seals
  noise pinholes. A larger kernel bridges the mouth of a crack and erases the
  feature Phase 2 measures.
- **Largest-component filter** rather than trusting `RETR_EXTERNAL` alone.
- **Blur (9,9)** chosen by sweep (3–15) ranked on defect-depth error — the
  quantity Phase 3 thresholds — not on how clean the mask looks.

### Results

| metric | result |
|---|---|
| contours per frame | **1** on all 20 |
| shape IoU (offset-compensated) | mean 0.953, min 0.939 |
| raw IoU | mean 0.871 |
| inward offset | 7.2 px |
| outline scatter about that offset | mean 2.65 px |
| part area | 30.0k–31.7k px² (5.5% spread) |

**About the 7.2 px inward offset.** The chamfered rim images as a brightness ramp
from belt to face; Otsu cuts partway up it, so the detected outline sits ~7 px
inside the true one. That is a near-uniform scale error, not a shape error — the
scatter around it is only 2.7 px — and a real camera sees the same thing.

It does not hurt the inspection, which is worth understanding rather than
patching: convexity depth is a *relative* measurement, so contour and hull shrink
together and largely cancel. Scaling the Otsu threshold down to force raw IoU up
buys ~5 IoU points and moves the PASS/FAIL margin by under a pixel — a magic
number with no payoff that would break on real images. Rejected.

Figures: `figures/stages.jpg`, `figures/silhouettes.png`.

---

## Phase 2 — Topological analysis ✅

`find_defects(contour)` returns every concavity, deepest first, as
`Defect(start, end, farthest, depth)`.

The convex hull is the rubber band stretched around the part. Wherever the real
outline falls away from that band — keyway, chip, crack — the gap is a convexity
defect. `farthest` is its deepest point, and the anchor for the Phase 3 bounding
box.

### Gotchas handled

- **The `/256` scaling.** `cv2.convexityDefects` returns depth as a fixed-point
  integer with 8 fractional bits. Divide by 256.0 or every distance is 256×
  too large.
- **Hull index order.** `convexityDefects` needs the hull as *indices*
  (`returnPoints=False`) and raises if they are non-monotonic on a degenerate
  contour. Caught, not crashed — this is meant to run on a line.
- **Sub-pixel wobble.** `min_depth=1.0` drops edge-noise concavities; real
  features are an order of magnitude deeper.

### Results

Every part carries a keyway, so a correct run finds **1** significant concavity
(≥ 4 px) on a PASS part and **2** on a FAIL part. That held on all 20.

| metric | result |
|---|---|
| significant concavities | 1 on every PASS, 2 on every FAIL |
| depth error vs true cut depth | mean **1.01 px**, max 1.70 px |
| location error vs true deepest point | mean **12.0 px**, max 17.4 px |

The ~12 px location error is expected and benign: the chamfer offsets the outline
inward by ~7 px, and the floor of a chip is an arc, so the single farthest point
can sit anywhere along it. It is nowhere near ambiguous — the nearest competing
feature is ~150 px away.

### Separation — the input to Phase 3

| | deepest concavity |
|---|---|
| PASS parts | 8.4 – 11.9 px (keyway) |
| FAIL parts | 22.4 – 40.9 px |

Gap **10.5 px** → `THRESHOLD_MAX = 17`.

Figure: `figures/defects.jpg` — red contour, green hull, cyan hull chord,
magenta depth measurement at each concavity.

---

## Phase 3 — Tolerance gate ✅

```python
result = inspect(image)      # Result(verdict, defects, all_defects, contour, stages, reason)
annotated = annotate(result) # outline, boxes on flagged defects, verdict banner
```

`THRESHOLD_MAX = 17.0` px. Any concavity deeper than that is a defect; anything
shallower is normal geometry (the keyway) or edge noise.

### Calibration — measured, not guessed

The keyway tops out at 11.9 px and the shallowest real defect is 22.4 px, so
every threshold in **12–22 px scores 20/20**. Shipping 17 puts the gate in the
middle of that window, maximising margin on both sides.

| limit (px) | accuracy | what breaks |
|---|---|---|
| 5 | 50% | 10 good parts rejected — the keyway itself trips the gate |
| 10 | 80% | 4 good parts rejected |
| **12 – 22** | **100%** | — |
| 24 | 95% | 1 bad part shipped |
| 30 | 80% | 4 bad parts shipped |
| 40 | 55% | 9 bad parts shipped |

`validate.py` prints this table every run, so the window is re-derived from the
data rather than trusted from a comment.

**The threshold is in pixels**, so it is tied to the camera's working distance.
Change the lens or the standoff and it must be recalibrated — which is why
`validate.py` reports the safe window rather than just a pass/fail.

### Design points

- **An empty frame is a FAIL, with a reason.** On a real line "I could not see a
  part" must never be mistaken for "the part is good".
- **The bounding box spans the whole missing-material region** — the points
  where the hull leaves and rejoins the outline, plus the deepest point between
  them — not just a dot on `farthest_point`. An operator needs to see what was
  rejected.
- **Every result carries its `reason` string**, so a verdict can be audited
  without re-running the pipeline.
- The failure asymmetry is worth naming: too low a threshold rejects good parts
  (expensive, visible); too high ships bad ones (expensive, invisible). The
  midpoint of the safe window is the only defensible default without a cost
  model from the customer.

Figure: `figures/results.jpg` — the verdict as an operator would see it.

## Phase 4 — Validation ✅

`python validate.py` writes the whole Phase 4 deliverable into **`results/`**:

```
results/report.md        confusion matrix, metrics, per-image table
results/predictions.csv  raw log: actual, predicted, worst depth, reason
results/margin.png       every measurement plotted against the tolerance
results/annotated/       all 20 frames with the verdict drawn on
```

### Result

```
                 predicted
                 PASS  FAIL
    actual PASS    10     0      <- FP = good part rejected
           FAIL     0    10      <- FN = bad part shipped
```

| metric | value |
|---|---|
| **accuracy** | **100%** (20/20) |
| precision | 100% |
| recall | 100% |
| false positives | 0 |
| false negatives | 0 |

No tuning was needed to reach it — the threshold came from Phase 3's calibration
and was not adjusted afterwards. Touching it here would have been fitting the
answer to the test set.

### Read the margin, not the score

`results/margin.png` is the more honest result. 100% on 20 images is a weak claim
on its own; what matters is that the two populations sit **10.5 px apart with
nothing in between**, so the verdict does not hinge on the exact threshold. Every
limit from 12 to 22 px gives the same 20/20.

The plot uses blue/orange rather than green/red: red-green is indistinguishable
to the most common form of colour blindness, and the row labels carry the
identity anyway.

### Honest caveats

- 20 images is a small set, and they are synthetic. The accuracy figure says the
  method is sound; it does not say it is production-ready.
- No borderline cases exist here — the shallowest defect is twice the deepest
  keyway. A real batch will have marginal parts, and that is where the
  false-positive/false-negative trade-off starts to cost money.
- Every part shares one nominal geometry, so nothing tests robustness to part
  variation.

## Phase 5 — Robustness and failure modes ✅

### Dynamic thresholding

`dataset/stress/` re-lights the same 20 parts under a severe illumination
gradient (one side of the frame far darker than the other), plus exposure error
and specular glare on the metal. Geometry is untouched, so any change in the
score is purely a thresholding failure.

`inspect(image, dynamic=True)` subtracts an estimated lighting field before
thresholding. The field is the image with the part removed — a morphological
opening with a structuring element larger than the part — computed at quarter
resolution, since a lighting field is smooth by nature.

| | clean set | stress set | cost |
|---|---|---|---|
| global Otsu | 20/20 | **18/20** | 9 ms |
| illumination-corrected | 20/20 | **20/20** | 17 ms |

Off by default: on evenly lit frames it buys nothing and costs 8 ms.

**The failures were not the ones expected.** The assumption was that bad light
would eat the outline and manufacture defects. Measured, it does the opposite —
both errors were **false negatives: defective parts passed**. On the shaded side
of the frame the chip's dark floor and the dark belt fall on the same side of the
single global threshold, so the notch fills in, the outline comes out smooth, and
the defect disappears. `figures/stress.jpg` shows it.

That is the dangerous direction — a rejected good part gets noticed, a defect
that silently stops being visible does not.

### Real-time defect counter on video

```bash
python inspection.py dataset/conveyor.mp4 --video --out results
→ 570 frames · 4.2 ms/frame (238 fps headroom)
→ 20 parts inspected · 10 passed · 10 rejected
```

Two details make the counter correct rather than approximately correct:

- **A part is only inspected when it is fully inside the frame.** The convex hull
  of an outline clipped by the frame edge is meaningless — it invents a huge
  defect along the cut. Frames without a whole part show `WAITING` and no verdict.
- **The tally is latched, the overlay is not.** Each part is counted once, on the
  frame where it first becomes fully visible, but it is re-inspected every frame
  so the boxes track the moving part. (First version latched the whole result and
  the overlay visibly lagged behind the part.)

The HUD shows inspected / passed / rejected and the running reject rate — the
number a line supervisor actually watches, since a jump in it means the process
drifted.

At 4.2 ms/frame the pipeline has roughly 240 fps of headroom on one core, so
"real-time" is not an aspiration here.

### False-positive write-up

`results/false-positives.md` — the full note, generated from the measured numbers
so it cannot drift out of date. The short version: the keyway is a legitimate
concavity up to 11.9 px deep, so any tolerance below that rejects **every** good
part. The tempting error is to set the threshold as a noise floor (~3 px); it has
to clear normal geometry, not noise.

## Phase 6 — Packaging ✅

- Every phase's code folded into the four modules above; `pyflakes` clean.
- `requirements.txt`, `.gitignore`, and this README.
- **Verified from a clean checkout**: copying only the four `.py` files plus
  `labels.csv` into an empty directory and running the three quickstart commands
  regenerates the dataset bit-for-bit (matching MD5s), reproduces every figure,
  and passes every check. Nothing depends on state left behind during development.
- **Video output fixed.** OpenCV's default build cannot encode H.264 and silently
  falls back to MPEG-4 Part 2, which browsers refuse to play — the file looks
  corrupt when it is merely unfashionable. `open_video_writer()` now probes codecs
  and `ensure_playable()` re-encodes through ffmpeg when it is available, saying so
  plainly when it is not. The codec probe's noise is suppressed at the file
  descriptor, since ffmpeg prints its complaints from C.

## What I would do differently

- **Build the stress set before the clean one.** My first lighting-stress attempt
  was unusable — glare bright enough to saturate the belt merges part and
  background into one white region, and no threshold separates two touching
  saturated areas. That is an optics problem, not an algorithm one. Knowing where
  the method genuinely breaks would have shaped the earlier phases.
- **Not assume the direction of a failure.** I wrote the false-positive note
  predicting bad lighting would manufacture defects. Measured, it did the
  opposite — it *hid* them. The note is now generated from the measured numbers
  so it cannot drift from reality again.
- **Ground truth from the start.** Exporting the true masks and defect coordinates
  from the generator turned "looks right" into a number. I added it during
  Phase 1; it should have existed in Phase 0.

## If this ran on a real line

- Recalibrate `THRESHOLD_MAX` on real good parts first — the deepest *legitimate*
  concavity is the floor, whatever the noise level suggests.
- Trigger on a sensor rather than inferring part presence from the image.
- Log every rejection with its frame. A reject rate that drifts is the earliest
  signal that the process or the lighting has changed.
- Watch for the failure mode that cannot be seen: a gate that is silently too
  permissive looks identical to one that is working.

## Known limits

- Synthetic glare is well behaved; real glare can blow out to background level
  and punch a hole in the silhouette. Expect Otsu alone to struggle on real
  captures — hence the dynamic thresholding planned for Phase 5.
- Every part here is the same nominal geometry. Real batches vary.
- **Convexity defects only catch defects that break the outline.** Surface
  scratches, stains and shallow dents are invisible to this method. If the real
  defects are surface-type, the approach must change (template differencing or
  blob detection on the face).

## Capture requirements for the real rig

- Top-down, sensor plane parallel to the belt; fixed height and focus — the
  threshold is in pixels, so the px→mm scale must stay constant
- Manual exposure and white balance locked; fast shutter if the belt moves
- Diffuse even lighting; kill specular glare (diffuser / polarizer); no hard
  shadow touching the part. Backlighting is the ideal case
- One part per frame, fully inside it, not touching edges, no overlap
- Strong part-vs-belt contrast; a defect should span ≥ 15–20 px
- Legit features (keyways, slots) present on good *and* bad parts; vary defect
  size, type and position; include borderline cases
