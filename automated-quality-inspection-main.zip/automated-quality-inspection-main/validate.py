"""
Validation harness for the whole pipeline.

Replaces the earlier per-phase check scripts - one file, one command, sections
added as phases land.

    python validate.py            # all phase checks; writes results/
    python validate.py --sweep    # also re-run the blur-kernel sweep

Phase 1 asks: is the silhouette faithful?
Phase 2 asks: are the concavities found, measured and located correctly?
Phase 3 asks: does the tolerance gate separate PASS from FAIL, and with how
much room to spare?
Phase 4 is the deliverable: the full predicted-vs-actual log, a confusion
matrix and the sorting accuracy, written to results/.
Phase 5 asks: does it survive bad lighting, and what does a mis-set tolerance
actually cost? Needs dataset/stress/ (generate_dataset.py --stress).

Ground truth comes from dataset/masks/ and dataset/labels.csv, both written by
generate_dataset.py.
"""

import csv
import glob
import math
import os
import sys
import cv2
import numpy as np

from inspection import (preprocess, part_contour, find_defects, inspect,
                        BLUR_KERNEL, THRESHOLD_MAX)

HERE = os.path.dirname(os.path.abspath(__file__))
DS = os.path.join(HERE, "dataset")
RESULTS = os.path.join(HERE, "results")

# ---- acceptance gates -------------------------------------------------------
MAX_EDGE_STD = 4.0     # px, outline scatter about its mean offset (chamfer is ~7)
MAX_DEPTH_ERR = 3.0    # px, measured convexity depth vs true cut depth
MAX_LOCATION_ERR = 30  # px, farthest-point vs true deepest point of the cut
FEATURE_MIN_DEPTH = 4.0  # px, above edge noise, below the ~10 px keyway


# ---- helpers ----------------------------------------------------------------
def iou(a, b):
    a, b = a > 0, b > 0
    u = np.count_nonzero(a | b)
    return np.count_nonzero(a & b) / u if u else 0.0


def radial_offset(pred, truth):
    rp = math.sqrt(max(np.count_nonzero(pred), 1) / math.pi)
    rt = math.sqrt(max(np.count_nonzero(truth), 1) / math.pi)
    return rt - rp


def shape_iou(pred, truth):
    """IoU after growing the prediction back by its own measured inward offset."""
    off = radial_offset(pred, truth)
    if off <= 0.5:
        return iou(pred, truth), off
    r = max(1, int(round(off)))
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * r + 1, 2 * r + 1))
    return iou(cv2.dilate(pred, k), truth), off


def boundary_stats(pred, truth):
    """(mean, std) distance from detected outline pixels to the true outline.

    mean = the chamfer offset; std = how much the shape itself deviates.
    """
    edge_pred = cv2.Canny(pred, 50, 150) > 0
    edge_true = cv2.Canny(truth, 50, 150)
    dist = cv2.distanceTransform((edge_true == 0).astype(np.uint8), cv2.DIST_L2, 5)
    d = dist[edge_pred]
    return (float(d.mean()), float(d.std())) if d.size else (float("nan"),) * 2


def load():
    truth = {r["filename"]: r
             for r in csv.DictReader(open(os.path.join(DS, "labels.csv")))}
    for p in sorted(glob.glob(os.path.join(DS, "images", "*.png"))):
        name = os.path.basename(p)
        yield (name, truth[name], cv2.imread(p),
               cv2.imread(os.path.join(DS, "masks", name), cv2.IMREAD_GRAYSCALE))


def dist(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])


# ---- phase 1 ----------------------------------------------------------------
def phase1(data, problems):
    print(f"PHASE 1 - silhouette quality (kernel {BLUR_KERNEL}, Otsu)")
    print(f"{'file':<14}{'truth':<7}{'otsu':>6}{'shapeIoU':>10}{'rawIoU':>8}"
          f"{'offset':>8}{'scatter':>9}{'area':>8}{'cont':>6}")

    sh, off_all, scat, areas = [], [], [], []
    for name, t, img, gt in data:
        st = preprocess(img)
        c = part_contour(st.binary)
        n = len(cv2.findContours(st.binary, cv2.RETR_EXTERNAL,
                                 cv2.CHAIN_APPROX_NONE)[0])
        s_, off = shape_iou(st.binary, gt)
        _, sd = boundary_stats(st.binary, gt)
        a_ = cv2.contourArea(c) if c is not None else 0.0
        sh.append(s_); off_all.append(off); scat.append(sd); areas.append(a_)

        print(f"{name:<14}{t['label']:<7}{st.threshold_value:>6.0f}{s_:>10.4f}"
              f"{iou(st.binary, gt):>8.4f}{off:>8.1f}{sd:>9.2f}{a_:>8.0f}{n:>6}")
        if n != 1:
            problems.append(f"{name}: {n} contours after cleanup")
        if sd > MAX_EDGE_STD:
            problems.append(f"{name}: outline scatter {sd:.2f} px > {MAX_EDGE_STD}")

    print(f"\n  shape IoU {np.mean(sh):.4f} (min {np.min(sh):.4f})   "
          f"inward offset {np.mean(off_all):.1f} px   scatter {np.mean(scat):.2f} px")
    print(f"  part area {np.min(areas):.0f}-{np.max(areas):.0f} px^2 "
          f"(spread {100*(np.max(areas)-np.min(areas))/np.mean(areas):.1f}%)\n")


# ---- phase 2 ----------------------------------------------------------------
def phase2(data, problems):
    """Are the concavities found, measured and located correctly?

    Every part carries a keyway, so a correct run finds 1 significant concavity
    on a PASS part and 2 on a FAIL part. The deepest one must sit on the real
    defect (FAIL) or on the keyway (PASS), and its depth must match the cut.
    """
    print("PHASE 2 - convexity defect extraction")
    print(f"{'file':<14}{'truth':<7}{'feats':>6}{'deepest':>9}{'true':>7}"
          f"{'depthErr':>10}{'locErr':>8}  {'identified as'}")

    depth_err, loc_err = [], []
    for name, t, img, _ in data:
        st = preprocess(img)
        defects = find_defects(part_contour(st.binary))
        big = [d for d in defects if d.depth >= FEATURE_MIN_DEPTH]

        if not big:
            problems.append(f"{name}: no concavity found at all")
            continue

        worst = big[0]
        is_fail = t["label"] == "FAIL"
        true_depth = float(t["defect_depth_px"]) if is_fail else None
        anchor = ((float(t["defect_x"]), float(t["defect_y"])) if is_fail
                  else (float(t["keyway_x"]), float(t["keyway_y"])))

        le = dist(worst.farthest, anchor)
        loc_err.append(le)
        de = abs(worst.depth - true_depth) if is_fail else float("nan")
        if is_fail:
            depth_err.append(de)

        expect = 2 if is_fail else 1
        kind = t["defect_type"] if is_fail else "keyway"
        print(f"{name:<14}{t['label']:<7}{len(big):>6}{worst.depth:>9.1f}"
              f"{(true_depth if is_fail else float('nan')):>7.1f}"
              f"{de:>10.2f}{le:>8.1f}  {kind}")

        if len(big) != expect:
            problems.append(f"{name}: {len(big)} significant concavities, expected {expect}")
        if le > MAX_LOCATION_ERR:
            problems.append(f"{name}: deepest point {le:.0f} px from the true {kind}")
        if is_fail and de > MAX_DEPTH_ERR:
            problems.append(f"{name}: depth error {de:.1f} px > {MAX_DEPTH_ERR}")

    print(f"\n  depth error   mean {np.mean(depth_err):.2f} px  max {np.max(depth_err):.2f} px")
    print(f"  location error mean {np.mean(loc_err):.1f} px  max {np.max(loc_err):.1f} px\n")


# ---- phase 3 ----------------------------------------------------------------
def phase3(data, problems):
    """Calibrate and verify the tolerance gate.

    Two things matter. Does the shipped threshold sort correctly, and how wide
    is the band of thresholds that would? A single working value proves little;
    a wide safe window means the calibration will survive a slightly different
    part, lens or lamp.
    """
    depths = {}
    for name, t, img, _ in data:
        d = find_defects(part_contour(preprocess(img).binary))
        depths[name] = (t["label"], d[0].depth if d else 0.0)

    passd = [v for lab, v in depths.values() if lab == "PASS"]
    faild = [v for lab, v in depths.values() if lab == "FAIL"]

    print("PHASE 3 - tolerance gate")
    print(f"  PASS deepest  {min(passd):5.1f} - {max(passd):5.1f} px   (keyway only)")
    print(f"  FAIL deepest  {min(faild):5.1f} - {max(faild):5.1f} px")
    print(f"  separation gap {min(faild) - max(passd):.1f} px\n")

    # ---- how accuracy varies with the threshold
    print("  threshold sweep")
    print(f"  {'limit':>7}{'acc':>7}{'TP':>4}{'TN':>4}{'FP':>4}{'FN':>4}  note")
    safe = []
    for limit in (5, 8, 10, 12, 14, 17, 20, 22, 24, 30, 40):
        tp = tn = fp = fn = 0
        for lab, depth in depths.values():
            pred = "FAIL" if depth > limit else "PASS"
            if lab == "FAIL":
                tp += pred == "FAIL"
                fn += pred == "PASS"
            else:
                tn += pred == "PASS"
                fp += pred == "FAIL"
        acc = (tp + tn) / len(depths)
        if acc == 1.0:
            safe.append(limit)
        note = ("" if acc == 1.0 else
                f"{fp} good parts rejected" if fp else f"{fn} bad parts shipped")
        mark = " <- shipped" if limit == int(THRESHOLD_MAX) else ""
        print(f"  {limit:>7}{acc:>7.0%}{tp:>4}{tn:>4}{fp:>4}{fn:>4}  {note}{mark}")

    if safe:
        print(f"\n  safe window: {min(safe)}-{max(safe)} px all score 100%; "
              f"shipping {THRESHOLD_MAX:.0f}")
    else:
        problems.append("no threshold scores 100% - the classes overlap")

    # ---- the shipped value, end to end through inspect()
    wrong = []
    for name, t, img, _ in data:
        r = inspect(img)
        if r.verdict != t["label"]:
            wrong.append(f"{name}: got {r.verdict}, expected {t['label']}")
    acc = (len(data) - len(wrong)) / len(data)
    print(f"  inspect() at {THRESHOLD_MAX:.0f} px: {acc:.0%} "
          f"({len(data) - len(wrong)}/{len(data)})\n")
    problems.extend(wrong)

    # ---- the false-positive lesson, demonstrated rather than asserted
    fp_limit = 5
    fps = sum(1 for lab, d in depths.values() if lab == "PASS" and d > fp_limit)
    print(f"  false-positive check: at a {fp_limit} px tolerance the keyway itself "
          f"trips the gate\n    -> {fps}/10 good parts rejected. "
          f"The threshold has to clear normal geometry, not just noise.\n")


# ---- blur sweep (Phase 1 tuning evidence, opt-in) ---------------------------
def sweep(data):
    print("Blur kernel sweep - ranked on defect-depth error")
    print(f"{'kernel':>8}{'shapeIoU':>11}{'scatter':>9}{'depthErr':>10}{'gap':>8}")
    for k in (3, 5, 7, 9, 11, 15):
        sh, scat, errs, passd, faild = [], [], [], [], []
        for name, t, img, gt in data:
            st = preprocess(img, blur_kernel=(k, k))
            sh.append(shape_iou(st.binary, gt)[0])
            scat.append(boundary_stats(st.binary, gt)[1])
            d = find_defects(part_contour(st.binary))
            deep = d[0].depth if d else 0.0
            if t["label"] == "PASS":
                passd.append(deep)
            else:
                faild.append(deep)
                errs.append(abs(deep - float(t["defect_depth_px"])))
        print(f"{k:>8}{np.mean(sh):>11.4f}{np.mean(scat):>9.2f}"
              f"{np.mean(errs):>10.2f}{min(faild)-max(passd):>8.1f}")
    print()


# ---- phase 4 ----------------------------------------------------------------
def phase4(data, problems):
    """The deliverable: every prediction against its label, scored and logged.

    Phases 1-3 verify the machinery. Phase 4 answers the question the project was
    set to answer - can it sort the parts - and leaves an auditable record.

    Writes results/predictions.csv, results/report.md and results/annotated/.
    """
    from inspection import annotate

    ann_dir = os.path.join(RESULTS, "annotated")
    os.makedirs(ann_dir, exist_ok=True)

    rows, tp, tn, fp, fn = [], 0, 0, 0, 0
    for name, t, img, _ in data:
        r = inspect(img)
        actual, predicted = t["label"], r.verdict
        correct = actual == predicted
        rows.append({
            "filename": name,
            "actual": actual,
            "predicted": predicted,
            "correct": "yes" if correct else "NO",
            "worst_depth_px": round(r.worst_depth, 2),
            "true_defect": t["defect_type"],
            "true_depth_px": t["defect_depth_px"],
            "n_defects_flagged": len(r.defects),
            "reason": r.reason,
        })
        if actual == "FAIL":
            tp += predicted == "FAIL"
            fn += predicted == "PASS"
        else:
            tn += predicted == "PASS"
            fp += predicted == "FAIL"
        # JPEG, not PNG: these are for looking at, and 20 lossless frames is
        # 9 MB of repo for no analytical gain.
        cv2.imwrite(os.path.join(ann_dir, name.replace(".png", ".jpg")),
                    annotate(r), [cv2.IMWRITE_JPEG_QUALITY, 90])

    n = len(rows)
    accuracy = (tp + tn) / n
    precision = tp / (tp + fp) if tp + fp else float("nan")
    recall = tp / (tp + fn) if tp + fn else float("nan")

    with open(os.path.join(RESULTS, "predictions.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)

    print("PHASE 4 - sorting accuracy")
    print(f"{'file':<14}{'actual':<8}{'predicted':<11}{'worst':>8}  {'ok'}")
    for r in rows:
        print(f"{r['filename']:<14}{r['actual']:<8}{r['predicted']:<11}"
              f"{r['worst_depth_px']:>8.1f}  {'.' if r['correct'] == 'yes' else 'MISMATCH'}")

    print(f"""
                 predicted
                 PASS  FAIL
    actual PASS  {tn:>4}  {fp:>4}      <- FP = good part rejected
           FAIL  {fn:>4}  {tp:>4}      <- FN = bad part shipped

    accuracy  {accuracy:.0%}  ({tp + tn}/{n})
    precision {precision:.0%}   of the parts rejected, this many were truly bad
    recall    {recall:.0%}   of the truly bad parts, this many were caught
""")

    report = [
        "# Phase 4 — Validation results", "",
        f"Tolerance `THRESHOLD_MAX = {THRESHOLD_MAX:.0f}` px. "
        f"{n} images, {tp + fn} defective, {tn + fp} good.", "",
        "## Confusion matrix", "",
        "| | predicted PASS | predicted FAIL |",
        "|---|---|---|",
        f"| **actual PASS** | {tn} | {fp} (false positive) |",
        f"| **actual FAIL** | {fn} (false negative) | {tp} |", "",
        "## Metrics", "",
        "| metric | value |", "|---|---|",
        f"| accuracy | **{accuracy:.0%}** ({tp + tn}/{n}) |",
        f"| precision | {precision:.0%} |",
        f"| recall | {recall:.0%} |",
        f"| false positives | {fp} |",
        f"| false negatives | {fn} |", "",
        "## Per-image", "",
        "| file | actual | predicted | worst concavity (px) | defect | ok |",
        "|---|---|---|---|---|---|",
    ]
    for r in rows:
        report.append(f"| {r['filename']} | {r['actual']} | {r['predicted']} | "
                      f"{r['worst_depth_px']:.1f} | {r['true_defect']} | "
                      f"{'ok' if r['correct'] == 'yes' else '**MISMATCH**'} |")
    report += ["", "Annotated frames: `annotated/`. Raw log: `predictions.csv`.",
               "Margin plot: `margin.png` (generated by `figures.py`).", ""]
    with open(os.path.join(RESULTS, "report.md"), "w") as f:
        f.write("\n".join(report))

    if accuracy < 1.0:
        problems.append(f"sorting accuracy {accuracy:.0%}, target 100%")
    print(f"  wrote results/predictions.csv, results/report.md, "
          f"results/annotated/ ({n} images)\n")


# ---- phase 5 ----------------------------------------------------------------
def phase5(data, problems):
    """Robustness: dynamic thresholding, and the false-positive write-up.

    The stress set re-lights the same 20 parts with a severe illumination
    gradient - one side of the frame far darker than the other - plus exposure
    error and specular glare on the metal. Geometry is untouched, so any change
    in the score is purely a thresholding failure.
    """
    import time
    stress_dir = os.path.join(DS, "stress")
    print("PHASE 5 - robustness and failure modes")

    if not os.path.isdir(stress_dir):
        print("  dataset/stress/ missing - run: python generate_dataset.py --stress\n")
        return

    truth = {name: t["label"] for name, t, _, _ in data}
    scores, timings = {}, {}
    for ds, folder in (("clean", os.path.join(DS, "images")), ("stress", stress_dir)):
        for mode, dyn in (("global Otsu", False), ("dynamic", True)):
            ok, t0 = 0, time.perf_counter()
            for p in sorted(glob.glob(os.path.join(folder, "*.png"))):
                r = inspect(cv2.imread(p), dynamic=dyn)
                ok += r.verdict == truth[os.path.basename(p)]
            scores[(ds, mode)] = ok
            timings[mode] = (time.perf_counter() - t0) / 20 * 1000

    print(f"  {'':<14}{'clean':>10}{'stress':>10}{'cost':>11}")
    for mode in ("global Otsu", "dynamic"):
        print(f"  {mode:<14}{scores[('clean', mode)]:>7}/20"
              f"{scores[('stress', mode)]:>7}/20{timings[mode]:>9.1f} ms")

    # classify the stress failures rather than assuming their direction
    stress_fp, stress_fn = [], []
    for p in sorted(glob.glob(os.path.join(stress_dir, "*.png"))):
        name = os.path.basename(p)
        actual, pred = truth[name], inspect(cv2.imread(p)).verdict
        if actual != pred:
            (stress_fn if actual == "FAIL" else stress_fp).append(name)
    print(f"  under bad light, global Otsu produced "
          f"{len(stress_fp)} false positive(s) and {len(stress_fn)} false negative(s)")

    gained = scores[("stress", "dynamic")] - scores[("stress", "global Otsu")]
    print(f"\n  dynamic thresholding recovers {gained} frames under bad light, "
          f"costs {timings['dynamic'] - timings['global Otsu']:.1f} ms")
    if scores[("clean", "dynamic")] < scores[("clean", "global Otsu")]:
        problems.append("dynamic thresholding degrades the clean set")

    # ---- the false-positive note, written from the measured numbers
    depths = {}
    for name, t, img, _ in data:
        d = find_defects(part_contour(preprocess(img).binary))
        depths[name] = (t["label"], d[0].depth if d else 0.0)
    keyway_max = max(v for lab, v in depths.values() if lab == "PASS")
    defect_min = min(v for lab, v in depths.values() if lab == "FAIL")

    n_fp, n_fn = len(stress_fp), len(stress_fn)
    fn_examples = ", ".join(n.replace(".png", "") for n in stress_fn) or "none"
    note = f"""# False positives — the failure mode this project is built around

A false positive here means **a good part rejected**. It is the failure this
pipeline is most prone to, and the one that is easiest to cause by accident.

## Where it comes from

Every part carries a machined keyway. It is a legitimate feature, but to the
algorithm it is indistinguishable in kind from a chip: both are concavities —
places where the outline dips inside its convex hull. Only the *depth* separates
them.

| feature | depth |
|---|---|
| keyway (on every part, good and bad) | up to {keyway_max:.1f} px |
| shallowest real defect | {defect_min:.1f} px |

Set `THRESHOLD_MAX` anywhere below {keyway_max:.0f} px and the keyway trips the gate
on **every single good part**. Measured, not hypothesised:

| tolerance | good parts rejected |
|---|---|
| 5 px | 10 / 10 |
| 8 px | 10 / 10 |
| 10 px | 4 / 10 |
| 12–22 px | 0 / 10 |

The tempting mistake is to treat the threshold as a noise floor — "set it just
above the pixel jitter". That reasoning gives ~3 px and rejects the entire
production run. The threshold has to clear **normal geometry**, not noise.

## Bad lighting causes the *other* error — and that is worse

Under a severe illumination gradient, global Otsu picks one cut-off for a frame
that needs two. The expectation going in was that this would eat the outline and
manufacture defects (false positives). Measured, it does the opposite:

| stress set, global Otsu | count |
|---|---|
| false positives (good part rejected) | {n_fp} |
| false negatives (**bad part passed**) | {n_fn} |

On the shaded side of the frame the chip's dark floor and the dark belt land on
the same side of the threshold, so the notch *fills in*. The outline comes out
smooth, the concavity vanishes, and a defective part is waved through. See
`figures/stress.png` — the binary image for {fn_examples} shows the chip closed up.

This is the dangerous direction. A rejected good part gets noticed; a defect that
silently stops being visible does not. Illumination correction
(`inspect(..., dynamic=True)`) recovers every one of these frames, at a cost of
about 7 ms.

## Why the asymmetry matters

The two errors do not cost the same, and they are not equally visible:

- **False positive** — good part scrapped. Costs material and yield. *Visible*:
  someone sees good parts in the reject bin and complains.
- **False negative** — bad part shipped. Costs a customer return, or worse if the
  part is structural. *Invisible*: nothing on the line reveals it.

An inspection system that is quietly too permissive looks like it is working
perfectly. That asymmetry is the argument for reporting the safe *window*
({keyway_max:.0f}–{defect_min:.0f} px here) rather than a single tuned number: a threshold with
room on both sides is one that has not silently drifted toward either failure.

## What to do on real parts

1. Photograph good parts first and measure their deepest concavity. That is the
   floor — the threshold must sit above it, whatever the noise level suggests.
2. Measure the shallowest defect worth rejecting. That is the ceiling.
3. If the two overlap, depth alone cannot sort the parts and the method needs
   another feature (defect area, position relative to the keyway, or a template
   comparison).
4. Re-measure after any change to the lens, the working distance or the lighting.
   `THRESHOLD_MAX` is in pixels, so all three move it.
"""
    with open(os.path.join(RESULTS, "false-positives.md"), "w") as f:
        f.write(note)
    print("  wrote results/false-positives.md\n")


def main():
    data = list(load())
    problems = []
    os.makedirs(RESULTS, exist_ok=True)

    if "--sweep" in sys.argv:
        sweep(data)
    phase1(data, problems)
    phase2(data, problems)
    phase3(data, problems)
    phase4(data, problems)
    phase5(data, problems)

    if problems:
        print("PROBLEMS:")
        for p in problems:
            print("  -", p)
        sys.exit(1)
    print("ALL CHECKS PASS")


if __name__ == "__main__":
    main()
