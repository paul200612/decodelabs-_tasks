"""
Generates every figure in figures/. One file, one command:

    python figures.py

    figures/dataset.jpg      the 20 validation images
    figures/stages.jpg       Phase 1: original -> gray -> blur -> binary -> outline
    figures/silhouettes.png  Phase 1: the binarized silhouette of all 20 frames
    figures/defects.jpg      Phase 2: contour, hull, and every concavity measured
    figures/results.jpg      Phase 3: the PASS/FAIL verdict as an operator sees it
    results/margin.png       Phase 4: every measurement against the tolerance
    figures/stress.jpg       Phase 5: where global Otsu breaks, and the fix

Photographic figures are written as JPEG and graphics (the binary silhouettes,
the margin plot) as PNG. Lossless compression of a rendered photograph costs
megabytes and buys nothing; lossy compression of a hard-edged plot shows.
"""

import csv
import glob
import os
import cv2
import numpy as np

from inspection import preprocess, part_contour, find_defects, inspect, annotate

HERE = os.path.dirname(os.path.abspath(__file__))
DS = os.path.join(HERE, "dataset")
FIG = os.path.join(HERE, "figures")
RESULTS = os.path.join(HERE, "results")
FONT = cv2.FONT_HERSHEY_SIMPLEX

RED, GREEN, YELLOW, CYAN, MAGENTA = ((0, 0, 255), (0, 255, 0), (0, 255, 255),
                                     (255, 255, 0), (255, 0, 255))


def bgr(img):
    return img if img.ndim == 3 else cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)


def caption(img, text, color=YELLOW, bottom=False):
    """Label a tile. bottom=True keeps the top of the frame clear - used for the
    Phase 3 results, where annotate() already draws its verdict banner there."""
    out = bgr(img).copy()
    h = out.shape[0]
    y0, y1, ty = (h - 26, h, h - 8) if bottom else (0, 26, 19)
    cv2.rectangle(out, (0, y0), (out.shape[1], y1), (0, 0, 0), -1)
    cv2.putText(out, text, (7, ty), FONT, 0.55, color, 1, cv2.LINE_AA)
    return out


def save(name, img, quality=88):
    """JPEG for photographs, PNG for graphics - chosen by the extension given."""
    path = os.path.join(FIG, name)
    if name.lower().endswith((".jpg", ".jpeg")):
        cv2.imwrite(path, img, [cv2.IMWRITE_JPEG_QUALITY, quality])
    else:
        cv2.imwrite(path, img)


def grid(tiles, cols, size):
    tiles = [cv2.resize(t, size) for t in tiles]
    rows = [np.hstack(tiles[i:i + cols]) for i in range(0, len(tiles), cols)]
    return np.vstack(rows)


def labels():
    return {r["filename"]: r
            for r in csv.DictReader(open(os.path.join(DS, "labels.csv")))}


def images():
    return sorted(glob.glob(os.path.join(DS, "images", "*.png")))


# --------------------------------------------------------------------- phase 1
def fig_stages(picks):
    rows = []
    for path, tag in picks:
        img = cv2.imread(path)
        st = preprocess(img)
        c = part_contour(st.binary)

        overlay = img.copy()
        if c is not None:
            cv2.drawContours(overlay, [c], -1, RED, 2)
            cv2.drawContours(overlay, [cv2.convexHull(c)], -1, GREEN, 1)

        cells = [caption(img, f"{tag}  1. original"),
                 caption(st.gray, "2. grayscale"),
                 caption(st.blurred, "3. blurred"),
                 caption(st.binary, f"4. Otsu binary (t={st.threshold_value:.0f})"),
                 caption(overlay, "5. contour (red) + hull (green)")]
        rows.append(grid(cells, 5, (400, 300)))
    save("stages.jpg", np.vstack(rows))


def fig_silhouettes():
    tiles = [caption(preprocess(cv2.imread(p)).binary, os.path.basename(p)[:-4])
             for p in images()]
    save("silhouettes.png", grid(tiles, 5, (256, 192)))


def fig_dataset():
    tiles = [caption(cv2.imread(p), os.path.basename(p)[:-4]) for p in images()]
    save("dataset.jpg", grid(tiles, 5, (320, 240)))


# --------------------------------------------------------------------- phase 2
def draw_defects(path, tag):
    """Outline, hull, and every concavity: chord in cyan, depth marked at the
    farthest point. This is what Phase 3 will threshold."""
    img = cv2.imread(path)
    st = preprocess(img)
    c = part_contour(st.binary)
    out = img.copy()
    if c is None:
        return caption(out, f"{tag}  no part")

    cv2.drawContours(out, [c], -1, RED, 1)
    cv2.drawContours(out, [cv2.convexHull(c)], -1, GREEN, 1)

    for d in find_defects(c, min_depth=4.0):
        cv2.line(out, d.start, d.end, CYAN, 1)          # the hull chord
        cv2.line(out, d.farthest, d.start, MAGENTA, 1)  # depth is measured to here
        cv2.circle(out, d.farthest, 4, MAGENTA, -1)
        x, y = d.farthest
        cv2.putText(out, f"{d.depth:.1f}px", (x + 8, y + 4), FONT, 0.5,
                    MAGENTA, 1, cv2.LINE_AA)
    return caption(out, tag)


def fig_defects(picks):
    tiles = [draw_defects(p, tag) for p, tag in picks]
    save("defects.jpg", grid(tiles, 3, (426, 320)))


# --------------------------------------------------------------------- phase 3
def fig_results(picks):
    """The inspection output itself: verdict banner, outline, flagged boxes."""
    tiles = [caption(annotate(inspect(cv2.imread(p))), tag, bottom=True)
             for p, tag in picks]
    save("results.jpg", grid(tiles, 3, (426, 320)))


# --------------------------------------------------------------------- phase 4
def fig_margin():
    """Every part's deepest concavity against the tolerance.

    One dot per part, split by its true class. Shows at a glance that the two
    populations do not touch, and how much room the threshold has on each side -
    which is the real result, more than "100%" is.

    Blue/orange rather than green/red: red-green is indistinguishable to the most
    common form of colour blindness. Identity is carried by the row label anyway.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from inspection import THRESHOLD_MAX

    BLUE, ORANGE = "#2a78d6", "#eb6834"      # CVD-validated pair
    INK, MUTED, SURFACE = "#0b0b0b", "#52514e", "#fcfcfb"

    truth = labels()
    good, bad = [], []
    for p in images():
        d = find_defects(part_contour(preprocess(cv2.imread(p)).binary))
        deep = d[0].depth if d else 0.0
        (bad if truth[os.path.basename(p)]["label"] == "FAIL" else good).append(deep)

    lo, hi = max(good), min(bad)            # the safe window for the threshold

    fig, ax = plt.subplots(figsize=(9, 3.1), dpi=170)
    fig.patch.set_facecolor(SURFACE)
    ax.set_facecolor(SURFACE)

    ax.axvspan(lo, hi, color="#e8e7e3", zorder=0)
    ax.axvline(THRESHOLD_MAX, color=INK, lw=2, zorder=3)
    ax.text(THRESHOLD_MAX, 1.62, f" tolerance {THRESHOLD_MAX:.0f} px",
            color=INK, fontsize=9, va="center")
    ax.text(THRESHOLD_MAX - 0.7, 0.38,
            f"any limit in {lo:.0f}-{hi:.0f} px sorts correctly",
            color=MUTED, fontsize=8.5, ha="right")

    ax.scatter(good, [1.2] * len(good), s=70, color=BLUE, zorder=4,
               edgecolor=SURFACE, linewidth=2, label="good parts (keyway only)")
    ax.scatter(bad, [0.8] * len(bad), s=70, color=ORANGE, zorder=4,
               edgecolor=SURFACE, linewidth=2, label="defective parts")

    ax.set_yticks([1.2, 0.8])
    ax.set_yticklabels(["PASS", "FAIL"], fontsize=10, color=INK)
    ax.set_ylim(0.25, 1.75)
    ax.set_xlim(0, max(bad) + 5)
    ax.set_xlabel("deepest convexity defect (px)", fontsize=9.5, color=MUTED)
    ax.set_title("Every measurement against the tolerance", fontsize=11,
                 color=INK, loc="left", pad=12)

    ax.grid(axis="x", color="#e8e7e3", lw=0.8, zorder=1)
    ax.set_axisbelow(True)
    for side in ("top", "right", "left"):
        ax.spines[side].set_visible(False)
    ax.spines["bottom"].set_color("#d8d7d3")
    ax.tick_params(colors=MUTED, length=0)
    ax.legend(frameon=False, fontsize=9, loc="upper right",
              bbox_to_anchor=(1.0, 1.28), ncol=2, labelcolor=MUTED)

    os.makedirs(RESULTS, exist_ok=True)
    fig.tight_layout()
    fig.savefig(os.path.join(RESULTS, "margin.png"), facecolor=SURFACE)
    plt.close(fig)


# --------------------------------------------------------------------- phase 5
def fig_stress():
    """The frames global Otsu gets wrong under a severe lighting gradient, and
    the same frames with illumination correction switched on."""
    from inspection import estimate_illumination

    stress = sorted(glob.glob(os.path.join(DS, "stress", "*.png")))
    if not stress:
        return
    truth = labels()

    picks = []
    for p in stress:
        name = os.path.basename(p)
        img = cv2.imread(p)
        if inspect(img).verdict != truth[name]["label"]:
            picks.append((p, name))
    picks = picks[:2] or [(stress[0], os.path.basename(stress[0]))]

    rows = []
    for p, name in picks:
        img = cv2.imread(p)
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        plain, dyn = inspect(img), inspect(img, dynamic=True)
        want = truth[name]["label"]
        cells = [
            caption(img, f"{name} [{want}] lighting gradient"),
            caption(estimate_illumination(gray), "estimated lighting field"),
            caption(plain.stages.binary,
                    f"global Otsu -> {plain.verdict}"
                    f"{'  WRONG' if plain.verdict != want else ''}",
                    color=RED if plain.verdict != want else YELLOW),
            caption(dyn.stages.binary,
                    f"illumination-corrected -> {dyn.verdict}"
                    f"{'  WRONG' if dyn.verdict != want else ''}",
                    color=RED if dyn.verdict != want else GREEN),
        ]
        rows.append(grid(cells, 4, (400, 300)))
    save("stress.jpg", np.vstack(rows))


# ------------------------------------------------------------------------ main
def main():
    os.makedirs(FIG, exist_ok=True)
    truth = labels()

    def pick(kind, n=1):
        out = []
        for p in images():
            r = truth[os.path.basename(p)]
            if r["defect_type"] == kind:
                out.append((p, f"{os.path.basename(p)[:-4]} [{r['label']}/{kind}]"))
            if len(out) == n:
                break
        return out

    fig_dataset()
    fig_stages(pick("none") + pick("chip") + pick("crack"))
    fig_silhouettes()
    six = pick("none", 2) + pick("chip", 2) + pick("crack", 2)
    fig_defects(six)
    fig_results(six)
    fig_margin()
    fig_stress()
    print("wrote figures/: dataset, stages, silhouettes, defects, results, stress")
    print("wrote results/margin.png")


if __name__ == "__main__":
    main()
