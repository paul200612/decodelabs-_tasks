# False positives — the failure mode this project is built around

A false positive here means **a good part rejected**. It is the failure this
pipeline is most prone to, and the one that is easiest to cause by accident.

## Where it comes from

Every part carries a machined keyway. It is a legitimate feature, but to the
algorithm it is indistinguishable in kind from a chip: both are concavities —
places where the outline dips inside its convex hull. Only the *depth* separates
them.

| feature | depth |
|---|---|
| keyway (on every part, good and bad) | up to 11.9 px |
| shallowest real defect | 22.4 px |

Set `THRESHOLD_MAX` anywhere below 12 px and the keyway trips the gate
on **every single good part**. Measured, not hypothesised:

| tolerance | good parts rejected |
|---|---|
| 5 px | 10 / 10 |
| 8 px | 10 / 10 |
| 10 px | 4 / 10 |
| 12–22 px | 0 / 10 |

The tempting mistake is to treat the threshold as a noise floor — "set it just
above the pixel jitter". That reasoning gives ~3 px and rejects the entire
production run. The threshold has to clear **normal geometry**, not noise.

## Bad lighting causes the *other* error — and that is worse

Under a severe illumination gradient, global Otsu picks one cut-off for a frame
that needs two. The expectation going in was that this would eat the outline and
manufacture defects (false positives). Measured, it does the opposite:

| stress set, global Otsu | count |
|---|---|
| false positives (good part rejected) | 0 |
| false negatives (**bad part passed**) | 2 |

On the shaded side of the frame the chip's dark floor and the dark belt land on
the same side of the threshold, so the notch *fills in*. The outline comes out
smooth, the concavity vanishes, and a defective part is waved through. See
`figures/stress.png` — the binary image for part_08, part_15 shows the chip closed up.

This is the dangerous direction. A rejected good part gets noticed; a defect that
silently stops being visible does not. Illumination correction
(`inspect(..., dynamic=True)`) recovers every one of these frames, at a cost of
about 7 ms.

## Why the asymmetry matters

The two errors do not cost the same, and they are not equally visible:

- **False positive** — good part scrapped. Costs material and yield. *Visible*:
  someone sees good parts in the reject bin and complains.
- **False negative** — bad part shipped. Costs a customer return, or worse if the
  part is structural. *Invisible*: nothing on the line reveals it.

An inspection system that is quietly too permissive looks like it is working
perfectly. That asymmetry is the argument for reporting the safe *window*
(12–22 px here) rather than a single tuned number: a threshold with
room on both sides is one that has not silently drifted toward either failure.

## What to do on real parts

1. Photograph good parts first and measure their deepest concavity. That is the
   floor — the threshold must sit above it, whatever the noise level suggests.
2. Measure the shallowest defect worth rejecting. That is the ceiling.
3. If the two overlap, depth alone cannot sort the parts and the method needs
   another feature (defect area, position relative to the keyway, or a template
   comparison).
4. Re-measure after any change to the lens, the working distance or the lighting.
   `THRESHOLD_MAX` is in pixels, so all three move it.
