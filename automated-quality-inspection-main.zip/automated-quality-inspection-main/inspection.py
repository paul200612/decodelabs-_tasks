"""
Automated Quality Inspection — shared pipeline module.

Phases 1-3 all live here, so the finished inspector is one import:

    from inspection import inspect, annotate
    result = inspect(cv2.imread(path))
    print(result.verdict)                    # "PASS" or "FAIL"
    cv2.imwrite("out.png", annotate(result))

Or from the command line:

    python inspection.py dataset/images/               # table of verdicts
    python inspection.py dataset/images/ --out runs    # also save annotated images
    python inspection.py dataset/images/ --dynamic     # illumination-corrected
    python inspection.py dataset/conveyor.mp4 --video --out results
"""

from contextlib import contextmanager
from dataclasses import dataclass
import os
import cv2
import numpy as np

# ----------------------------------------------------------------- parameters
BLUR_KERNEL = (9, 9)   # tuned in validate.py --sweep: lowest defect-depth error
MIN_PART_AREA = 2000   # px^2; anything smaller is belt dust, not a part

# Dynamic (illumination-corrected) thresholding - Phase 5.
# Off by default: on evenly lit frames it costs ~6 ms and buys nothing.
BG_KERNEL = 63         # structuring element, at BG_SCALE - must exceed the part
BG_SCALE = 4           # estimate the background at 1/4 size; ~15x faster


@dataclass
class Stages:
    """Every intermediate image, kept so the pipeline can be inspected/debugged."""
    original: np.ndarray
    gray: np.ndarray
    blurred: np.ndarray
    binary: np.ndarray
    threshold_value: float


# ------------------------------------------------------------------- phase 1
def estimate_illumination(gray, kernel=BG_KERNEL, scale=BG_SCALE):
    """Estimate the lighting field: the image with the part removed.

    A morphological opening with a structuring element LARGER than the part
    erases the part and leaves whatever the lamp is doing to the belt. Run at
    1/scale resolution because the field is smooth by nature - a 63 px kernel
    at quarter size is a 252 px kernel at full size, for ~1/15th the work.
    """
    small = cv2.resize(gray, None, fx=1 / scale, fy=1 / scale,
                       interpolation=cv2.INTER_AREA)
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (kernel, kernel))
    bg = cv2.morphologyEx(small, cv2.MORPH_OPEN, k)
    bg = cv2.resize(bg, (gray.shape[1], gray.shape[0]),
                    interpolation=cv2.INTER_CUBIC)
    return cv2.GaussianBlur(bg, (0, 0), 9)


def preprocess(image, blur_kernel=BLUR_KERNEL, dynamic=False):
    """Isolate the part silhouette from the conveyor belt.

    grayscale -> [illumination correction] -> Gaussian blur -> Otsu -> cleanup.

    dynamic=True subtracts the estimated lighting field before thresholding, so
    a single global cut-off works even when one side of the frame is far darker
    than the other. Needed when the shaded edge of the part is darker than the
    lit belt opposite it - see Phase 5 in the README.

    Otsu rather than a fixed threshold: exposure, lamp position and belt
    brightness vary shot to shot, so a hard-coded cut-off drifts out of
    calibration. Otsu re-derives the cut-off per image from its own histogram.

    Returns a Stages object; `binary` is the silhouette (part = 255).
    """
    if image is None:
        raise ValueError("image is None - check the path")

    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if image.ndim == 3 else image
    if dynamic:
        gray = cv2.subtract(gray, estimate_illumination(gray))
    blurred = cv2.GaussianBlur(gray, blur_kernel, 0)

    # Otsu picks the threshold; the 0 we pass is ignored, the chosen value is returned
    thresh_value, binary = cv2.threshold(
        blurred, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU
    )

    # The part is brighter than the belt. If that ever inverts (dark part, light
    # belt, or backlighting), flip so "part = white" always holds downstream.
    if np.count_nonzero(binary) > binary.size * 0.5:
        binary = cv2.bitwise_not(binary)

    binary = clean_mask(binary)
    return Stages(image, gray, blurred, binary, thresh_value)


def clean_mask(binary):
    """Remove belt dust and close pinholes without rounding off real defects.

    Opening with a small ellipse deletes specks; closing seals noise pinholes
    inside the part. The kernel is deliberately small (5 px) - a large one would
    bridge the mouth of a crack and erase the very feature Phase 2 measures.
    """
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
    binary = cv2.morphologyEx(binary, cv2.MORPH_OPEN, k)
    binary = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, k)

    # keep only the largest blob: one part per frame
    n, labels, stats, _ = cv2.connectedComponentsWithStats(binary, connectivity=8)
    if n <= 1:
        return binary
    biggest = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    if stats[biggest, cv2.CC_STAT_AREA] < MIN_PART_AREA:
        return np.zeros_like(binary)          # no part in frame
    return np.where(labels == biggest, 255, 0).astype(np.uint8)


def part_contour(binary):
    """Outer contour of the part, or None if the frame is empty.

    RETR_EXTERNAL: only the outer boundary. Holes and surface marks inside the
    part are irrelevant to an outline-based defect test.
    """
    contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    if not contours:
        return None
    return max(contours, key=cv2.contourArea)


# ------------------------------------------------------------------- phase 2
@dataclass
class Defect:
    """One concavity in the outline - a gap between the contour and its hull.

    depth is in pixels: how far the outline dips inside the convex hull at its
    worst point. That is the number Phase 3 thresholds.
    """
    start: tuple      # where the hull segment leaves the contour
    end: tuple        # where it rejoins
    farthest: tuple   # deepest point of the concavity  <- bounding box anchor
    depth: float      # px


def find_defects(contour, min_depth=1.0):
    """Every convexity defect in the outline, deepest first.

    The convex hull is the rubber band stretched around the part. Wherever the
    real outline falls away from that band - a keyway, a chip, a crack - the gap
    is a "convexity defect". cv2 reports each as (start, end, farthest, depth).

    Two gotchas are handled here:

    1. **The /256 scaling.** cv2.convexityDefects returns the depth as a fixed-
       point integer, 8 fractional bits. Divide by 256.0 or every distance comes
       out 256x too large.
    2. **Hull index order.** convexityDefects needs the hull as *indices*
       (returnPoints=False) and raises if those indices are not monotonic. That
       happens on degenerate contours, so it is caught rather than crashing a
       production line.

    min_depth drops sub-pixel wobble from edge noise; real features are >> 1 px.
    """
    if contour is None or len(contour) < 5:
        return []

    hull = cv2.convexHull(contour, returnPoints=False)
    if hull is None or len(hull) < 3:
        return []

    try:
        raw = cv2.convexityDefects(contour, hull)
    except cv2.error:
        return []                      # non-monotonic hull on a degenerate shape
    if raw is None:
        return []

    defects = []
    for s_idx, e_idx, f_idx, fixed_depth in raw[:, 0]:
        depth = fixed_depth / 256.0    # gotcha 1
        if depth < min_depth:
            continue
        defects.append(Defect(
            start=tuple(int(v) for v in contour[s_idx][0]),
            end=tuple(int(v) for v in contour[e_idx][0]),
            farthest=tuple(int(v) for v in contour[f_idx][0]),
            depth=float(depth),
        ))

    defects.sort(key=lambda d: d.depth, reverse=True)
    return defects


def deepest_defect(contour):
    """The single worst concavity, or None on a perfectly convex outline."""
    d = find_defects(contour)
    return d[0] if d else None


# ------------------------------------------------------------------- phase 3
# The tolerance gate. Any concavity deeper than this is a defect; anything
# shallower is normal geometry (the keyway) or edge noise.
#
# Calibrated in validate.py, not guessed: on the validation set the keyway tops
# out at 11.9 px and the shallowest real defect is 22.4 px, so anything in
# 12-22 px scores 20/20. 17 is the midpoint - maximum margin on both sides.
#
# THIS NUMBER IS IN PIXELS, so it is tied to the camera's working distance.
# Change the lens or the standoff and it must be recalibrated.
THRESHOLD_MAX = 17.0

BOX_PADDING = 10       # px of breathing room around a flagged defect


@dataclass
class Result:
    """Everything the inspection concluded, and the evidence for it."""
    verdict: str          # "PASS" or "FAIL"
    defects: list         # concavities that broke the tolerance
    all_defects: list     # every concavity found, deepest first
    contour: object       # the part outline, or None
    stages: Stages        # pre-processing intermediates, for debugging
    reason: str           # human-readable explanation of the verdict

    @property
    def worst_depth(self):
        return self.all_defects[0].depth if self.all_defects else 0.0


def inspect(image, threshold=THRESHOLD_MAX, dynamic=False):
    """Full inspection: image in, PASS/FAIL out.

    An empty frame is reported as FAIL with an explicit reason rather than a
    silent PASS - on a real line, "I could not see a part" must never be
    mistaken for "the part is good".
    """
    stages = preprocess(image, dynamic=dynamic)
    contour = part_contour(stages.binary)

    if contour is None:
        return Result("FAIL", [], [], None, stages, "no part found in frame")

    all_defects = find_defects(contour)
    over = [d for d in all_defects if d.depth > threshold]

    if over:
        worst = over[0]
        reason = (f"{len(over)} defect(s) over tolerance; "
                  f"deepest {worst.depth:.1f} px at {worst.farthest} "
                  f"(limit {threshold:.0f} px)")
        return Result("FAIL", over, all_defects, contour, stages, reason)

    deepest = all_defects[0].depth if all_defects else 0.0
    return Result("PASS", [], all_defects, contour, stages,
                  f"deepest concavity {deepest:.1f} px, within the "
                  f"{threshold:.0f} px tolerance")


def defect_box(defect, pad=BOX_PADDING):
    """Bounding box around a flagged defect: (x, y, w, h).

    Spans the whole missing-material region - the two points where the hull
    leaves and rejoins the outline, plus the deepest point between them - rather
    than just a dot on farthest_point, so an operator can see what was rejected.
    """
    pts = np.array([defect.start, defect.end, defect.farthest])
    x, y, w, h = cv2.boundingRect(pts)
    return x - pad, y - pad, w + 2 * pad, h + 2 * pad


def annotate(result, image=None):
    """Draw the verdict onto the frame: outline, flagged boxes, banner."""
    img = (image if image is not None else result.stages.original).copy()
    red, green, white = (0, 0, 255), (0, 200, 0), (255, 255, 255)
    colour = red if result.verdict == "FAIL" else green

    if result.contour is not None:
        cv2.drawContours(img, [result.contour], -1, colour, 2)

    for d in result.defects:
        x, y, w, h = defect_box(d)
        cv2.rectangle(img, (x, y), (x + w, y + h), red, 2)
        cv2.putText(img, f"{d.depth:.0f}px", (x, max(y - 6, 14)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.55, red, 2, cv2.LINE_AA)

    cv2.rectangle(img, (0, 0), (img.shape[1], 34), colour, -1)
    cv2.putText(img, result.verdict, (10, 25), cv2.FONT_HERSHEY_SIMPLEX,
                0.8, white, 2, cv2.LINE_AA)
    cv2.putText(img, result.reason, (95, 23), cv2.FONT_HERSHEY_SIMPLEX,
                0.45, white, 1, cv2.LINE_AA)
    return img


# ---------------------------------------------------------------------- cli
def _main(argv):
    import glob

    args = [a for a in argv if not a.startswith("--")]
    if not args:
        print(__doc__)
        return 1

    target = args[0]
    dynamic = "--dynamic" in argv
    out_dir = None
    if "--out" in argv:
        out_dir = argv[argv.index("--out") + 1]
        os.makedirs(out_dir, exist_ok=True)

    if "--video" in argv:
        out_path = os.path.join(out_dir, "conveyor_inspected.mp4") if out_dir else None
        inspect_video(target, out_path, dynamic=dynamic)
        return 0

    paths = (sorted(glob.glob(os.path.join(target, "*.png")) +
                    glob.glob(os.path.join(target, "*.jpg")))
             if os.path.isdir(target) else [target])
    if not paths:
        print(f"no images found in {target}")
        return 1

    print(f"{'file':<16}{'verdict':<9}{'worst':>8}  reason")
    failures = 0
    for p in paths:
        image = cv2.imread(p)
        if image is None:
            print(f"{os.path.basename(p):<16}{'ERROR':<9}{'':>8}  unreadable")
            continue
        r = inspect(image, dynamic=dynamic)
        failures += r.verdict == "FAIL"
        print(f"{os.path.basename(p):<16}{r.verdict:<9}{r.worst_depth:>8.1f}  {r.reason}")
        if out_dir:
            cv2.imwrite(os.path.join(out_dir, os.path.basename(p)), annotate(r))

    print(f"\n{len(paths)} inspected, {failures} rejected, "
          f"{len(paths) - failures} passed  (tolerance {THRESHOLD_MAX:.0f} px)")
    if out_dir:
        print(f"annotated images written to {out_dir}/")
    return 0




# ------------------------------------------------------------------- phase 5
FRAME_MARGIN = 6       # px; a part touching the frame edge is not fully in view


@contextmanager
def _quiet_stderr():
    """Silence file descriptor 2 for the duration of the block.

    Probing codecs is a try-and-see affair, and the failures are printed by
    ffmpeg's C code, not by Python - so redirecting sys.stderr is not enough and
    OpenCV's own log level does not cover it. The fd has to be swapped.
    """
    devnull = os.open(os.devnull, os.O_WRONLY)
    saved = os.dup(2)
    try:
        os.dup2(devnull, 2)
        yield
    finally:
        os.dup2(saved, 2)
        os.close(saved)
        os.close(devnull)


def open_video_writer(path, fps, size):
    """A VideoWriter, trying the most portable codec this build can actually do.

    Codec support depends on how OpenCV was compiled, so ask rather than assume:
    isOpened() is the only honest test. Falls back to Motion JPEG in an .avi,
    which every build can write.

    Returns (writer, path) - the path may have changed extension.
    """
    with _quiet_stderr():          # a missing codec is expected, not an error
        for tag, ext in (("avc1", ".mp4"), ("mp4v", ".mp4"), ("MJPG", ".avi")):
            candidate = os.path.splitext(path)[0] + ext
            writer = cv2.VideoWriter(candidate, cv2.VideoWriter_fourcc(*tag),
                                     fps, size)
            if writer.isOpened():
                return writer, candidate
            writer.release()
    raise RuntimeError("no usable video codec in this OpenCV build")


def ensure_playable(path):
    """Re-encode to H.264 if ffmpeg is around.

    Most OpenCV builds cannot encode H.264 and quietly fall back to MPEG-4
    Part 2 ('mp4v'). The file is valid, but browsers and many players refuse it -
    which looks exactly like a corrupt download. If ffmpeg is installed, convert;
    if not, say so rather than leaving a file that mysteriously will not open.
    """
    import shutil
    import subprocess

    if shutil.which("ffmpeg") is None:
        print(f"  note: {os.path.basename(path)} is MPEG-4 Part 2 and may not play "
              f"in a browser. Install ffmpeg, or open it in VLC.")
        return path

    out = os.path.splitext(path)[0] + "_h264.mp4"
    cmd = ["ffmpeg", "-y", "-loglevel", "error", "-i", path,
           "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "23",
           "-movflags", "+faststart", out]
    try:
        subprocess.run(cmd, check=True)
    except (subprocess.CalledProcessError, OSError):
        return path
    os.replace(out, path if path.endswith(".mp4") else out)
    return path if path.endswith(".mp4") else out


def part_fully_visible(contour, shape, margin=FRAME_MARGIN):
    """Is the whole part inside the frame?

    A part halfway into view has an outline clipped by the frame edge, and the
    convex hull of a clipped shape is meaningless - it would invent a huge
    'defect' along the cut. Real lines solve this with a trigger sensor; with
    only the image, the bounding box has to clear the border.
    """
    x, y, w, h = cv2.boundingRect(contour)
    H, W = shape[:2]
    return (x > margin and y > margin and
            x + w < W - margin and y + h < H - margin)


def inspect_video(source, out_path=None, dynamic=False, show_every=1):
    """Inspect a moving belt, counting each part exactly once.

    A part is inspected on the frame where it first becomes fully visible; the
    verdict is then latched until it leaves. Without that latch the counter
    would tick once per frame and report hundreds of parts.

    Returns (inspected, passed, rejected).
    """
    import time

    cap = cv2.VideoCapture(source)
    if not cap.isOpened():
        raise SystemExit(f"cannot open {source}")

    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    writer = None
    if out_path:
        writer, out_path = open_video_writer(out_path, fps, (w, h))

    inspected = passed = rejected = 0
    counted = False                # has the part currently in view been tallied?
    proc_ms = []

    while True:
        ok, frame = cap.read()
        if not ok:
            break

        t0 = time.perf_counter()
        stages = preprocess(frame, dynamic=dynamic)
        contour = part_contour(stages.binary)
        whole = contour is not None and part_fully_visible(contour, frame.shape)

        # Re-inspect every frame the part is fully visible - it is moving, so a
        # verdict latched to an older frame would draw its boxes in the wrong
        # place. Only the TALLY is latched, via `counted`.
        result = inspect(frame, dynamic=dynamic) if whole else None

        if whole and not counted:
            counted = True
            inspected += 1
            if result.verdict == "FAIL":
                rejected += 1
            else:
                passed += 1
        elif not whole:
            counted = False                             # part has left the view
        proc_ms.append((time.perf_counter() - t0) * 1000)

        out = annotate(result, frame) if result else _waiting_frame(frame, contour)
        _draw_hud(out, inspected, passed, rejected, proc_ms[-1])
        if writer:
            writer.write(out)

    cap.release()
    if writer:
        writer.release()
        out_path = ensure_playable(out_path)

    avg = sum(proc_ms) / max(len(proc_ms), 1)
    print(f"{len(proc_ms)} frames · {avg:.1f} ms/frame ({1000 / avg:.0f} fps headroom)")
    print(f"{inspected} parts inspected · {passed} passed · {rejected} rejected")
    if out_path:
        print(f"annotated video written to {out_path}")
    return inspected, passed, rejected


def _waiting_frame(frame, contour):
    """No whole part in view: show the outline, but pass no judgement."""
    out = frame.copy()
    grey = (150, 150, 150)
    if contour is not None:
        cv2.drawContours(out, [contour], -1, grey, 1)
    cv2.rectangle(out, (0, 0), (out.shape[1], 34), (70, 70, 70), -1)
    cv2.putText(out, "WAITING", (10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.8,
                (230, 230, 230), 2, cv2.LINE_AA)
    cv2.putText(out, "no complete part in frame", (135, 23),
                cv2.FONT_HERSHEY_SIMPLEX, 0.45, (230, 230, 230), 1, cv2.LINE_AA)
    return out


def _draw_hud(img, inspected, passed, rejected, ms):
    """Running tally, bottom-left. The reject rate is the number a line
    supervisor actually watches - a jump in it means the process drifted."""
    h = img.shape[0]
    rate = (rejected / inspected * 100) if inspected else 0.0
    lines = [f"inspected {inspected}",
             f"passed    {passed}",
             f"rejected  {rejected}   ({rate:.0f}%)",
             f"{ms:.0f} ms/frame"]
    cv2.rectangle(img, (8, h - 92), (196, h - 8), (0, 0, 0), -1)
    for i, line in enumerate(lines):
        colour = (170, 170, 170) if i == 3 else (255, 255, 255)
        cv2.putText(img, line, (16, h - 72 + i * 18), cv2.FONT_HERSHEY_SIMPLEX,
                    0.45, colour, 1, cv2.LINE_AA)


if __name__ == "__main__":
    import sys
    sys.exit(_main(sys.argv[1:]))
