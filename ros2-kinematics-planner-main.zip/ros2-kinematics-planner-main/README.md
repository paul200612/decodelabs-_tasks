# ros2-kinematics-planner
ROS 2 high-level motion planning node using the TRAC-IK solver to calculate precise joint angles for a 6-DOF manipulator.
