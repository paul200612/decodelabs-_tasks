import rclpy
import numpy as np
from rclpy.node import Node
from rclpy.action import ActionClient
from tf2_ros.buffer import Buffer
from tf2_ros.transform_listener import TransformListener
from rclpy.duration import Duration
from control_msgs.action import FollowJointTrajectory
from trac_ik import TracIK

class KinematicPlanner(Node):
    def __init__(self):
        super().__init__('kinematic_planner')
        
        self.tf_buffer = Buffer(cache_time=Duration(seconds=5.0))
        self.tf_listener = TransformListener(self.tf_buffer, self)
        
        self.trajectory_client = ActionClient(
            self, 
            FollowJointTrajectory, 
            '/joint_trajectory_controller/follow_joint_trajectory'
        )
        self.get_logger().info("Planner Node Initialized. Ready for Target Matrices.")

    def calculate_ik(self):
        # Target matrix (Point B converted to meters)
        target_matrix = np.array([
            [ 0.93, -0.13,  0.32,  0.45021],
            [ 0.19,  0.58, -0.05, -0.12055],
            [-0.22,  0.05,  0.84,  0.31000],
            [ 0.00,  0.00,  0.00,    1.00]
        ])
        
        # Read the URDF file directly for the standalone solver
        try:
            with open('src/single_rrbot.urdf', 'r') as file:
                urdf_text = file.read()
        except FileNotFoundError:
            self.get_logger().error("URDF file not found. Execute the script from ~/ros2_ws")
            return None
            
        # Initialize TRAC-IK (Positional arguments only)
        ik_solver = TracIK("base_link", "end_effector_link", urdf_text)
        
        # Calculate joint angles using the 4x4 target matrix directly
        joint_angles = ik_solver.ik(target_matrix)
        
        if joint_angles is not None:
            self.get_logger().info(f"Solved Joint Angles: {joint_angles}")
            return joint_angles
        else:
            self.get_logger().error("IK Solver failed to find a valid solution.")
            return None

def main(args=None):
    rclpy.init(args=args)
    node = KinematicPlanner()
    node.calculate_ik() # Execute the IK math
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()